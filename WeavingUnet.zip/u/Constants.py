import os
import shutil
import cv2
Image_size = (1024, 1024)
ROOT = r'   '   #modify to your path
BATCHSIZE_PER_CARD = 2
TOTAL_EPOCH = 1000
INITAL_EPOCH_LOSS = 10000
INITAL_EVAL_EPOCH_LOSS = 10000
NUM_EARLY_STOP = 8
NUM_UPDATE_LR = 5

BINARY_CLASS = 1


from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import os
from time import time
import datetime
import torch
import torch.utils.data as data
# framework：保存基本框架，测试图像，进行训练，导入保存的模型等功能的函数
from u.framework import MyFrame
# loss：定义损失函数，diceloss， 多类的diceloss，focalloss等
from u.loss import dice_bce_loss
# data ：定义数据，定义数据的导入，数据的扩增函数
from u.data import ImageFolder
from tqdm import tqdm
# 定义超参数，图像大小，图像的
import u.Constants as Constants
import warnings

# 导入自己的模型

from networks.WeavingUnet import WeavingUnet

# 忽略警告信息
warnings.filterwarnings("ignore")
###########修改使用的显卡
# Please specify the ID of graphics cards that you want to use
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def Net_Train():
    NAME = 'WeavingUnet-dg'
    print(NAME)
    # run the Visdom
    # viz = Visualizer(env=NAME)

    solver = MyFrame(WeavingUnet, dice_bce_loss, 2e-4)

    batchsize = torch.cuda.device_count() * Constants.BATCHSIZE_PER_CARD

    #############修改自己的数据集地址
    # dataset = ImageFolder(root_path=Constants.ROOT, datasets='DRIVE')
    # 加载训练数据集
    train_dataset = ImageFolder(root_path=Constants.ROOT, datasets='DRIVE')
    train_data_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=batchsize,
        shuffle=True,
        num_workers=4,
        pin_memory=True)

    # 判断是否需要断点接续训练
    initepoch = 1
    init_time = 0
    resume = True  # 设置是否需要从上次的状态继续训练
    if resume:
        if os.path.isfile("./weights/last_weights/" + NAME + "_last_model.pth"):
            print("Resume from checkpoint...")
            checkpoint = torch.load("./weights/last_weights/" + NAME + "_last_model.pth")
            solver.load_state_dict(checkpoint['model_state_dict'])
            solver.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            solver.old_lr = solver.optimizer.state_dict()['param_groups'][0]['lr']
            initepoch = checkpoint['epoch'] + 1
            init_time = checkpoint['total_time']
            train_epoch_best_loss = checkpoint['train_epoch_best_loss']
            no_optim = checkpoint['no_optim']
            print("====>loaded checkpoint (epoch:{})".format(checkpoint['epoch']))
            # start the logging files
            mylog = open('C:/Users/xianzhi/Desktop/experiment/logs/' + NAME + '.log', 'a')
        else:
            print("====>no checkpoint found.")
            initepoch = 1  # 如果没进行训练过，初始训练epoch值为0
            init_time = 0
            no_optim = 0
            train_epoch_best_loss = Constants.INITAL_EPOCH_LOSS
            # start the logging files
            mylog = open('C:/Users/xianzhi/Desktop/experiment/logs/' + NAME + '.log', 'w')

    tic = time()

    total_epoch = Constants.TOTAL_EPOCH

    for epoch in range(initepoch, total_epoch + 1):
        train_data_loader_num = iter(train_data_loader)
        train_epoch_loss = 0
        loop_train = tqdm(enumerate(train_data_loader), total=len(train_data_loader))
        for index, (img, mask) in loop_train:
            solver.set_input(img, mask)
            train_loss, pred = solver.optimize()
            train_epoch_loss += train_loss
            # index = index + 1

            loop_train.set_description(f'Epoch [{epoch}/{total_epoch}]')
            loop_train.set_postfix(loss=train_loss.item())

        train_epoch_loss = train_epoch_loss / len(train_data_loader_num)
        # 将信息保存在log文件夹中
        current_time = datetime.datetime.now()
        total_time = int(time() - tic) + init_time
        print('********', file=mylog)
        print("current_time:    " + str(current_time), file=mylog)
        print('epoch:', epoch, '    time:', total_time, file=mylog)
        print('train_loss:', train_epoch_loss, file=mylog)
        print('SHAPE:', Constants.Image_size, file=mylog)
        # 控制台打印信息
        tqdm.write('********')
        tqdm.write('epoch:' + str(epoch) + '    time:' + str(total_time))
        tqdm.write("current_time:    " + str(current_time))
        tqdm.write('train_loss:' + str(train_epoch_loss))
        tqdm.write('SHAPE:' + str(Constants.Image_size))

        # 保存损失最低的模型
        if train_epoch_loss >= train_epoch_best_loss:
            no_optim += 1
        else:
            no_optim = 0
            train_epoch_best_loss = train_epoch_loss
            solver.save('C:/Users/xianzhi/Desktop/experiment/weights/best_weights/'+ NAME + "_best_model.pth")
            print("!!--Best Model has Update--!!")

        # # 保存每一轮训练权重
        # # save epoch model
        # torch.save(solver.save("./weights/" + NAME + "-{}.pth".format(epoch)))
        # save last model
        checkpoint = {"model_state_dict": solver.net.state_dict(),
                      "optimizer_state_dict": solver.optimizer.state_dict(),
                      "epoch": epoch,
                      "train_epoch_best_loss": train_epoch_best_loss,
                      "no_optim": no_optim,
                      "total_time": total_time}
        path_checkpoint = 'C:/Users/xianzhi/Desktop/experiment/weights/last_weights/' + NAME + "_last_model.pth"
        torch.save(checkpoint, path_checkpoint)
        print("!!--Last Model has Update({})--!!".format(epoch))

        # 连续8轮损失不下降，早停
        if no_optim > Constants.NUM_EARLY_STOP:
            print('early stop at %d epoch' % epoch, file=mylog)
            print('early stop at %d epoch' % epoch)
            break
        if no_optim > Constants.NUM_UPDATE_LR:
            if solver.old_lr < 5e-7:
                break
            solver.load('C:/Users/xianzhi/Desktop/experiment/weights/best_weights/'+ NAME + '_best_model.pth')
            solver.update_lr(5.0, factor=True, mylog=mylog)                       #55555 22222
        mylog.flush()

    print('Finish!', file=mylog)
    print('Finish!')
    mylog.close()

if __name__ == '__main__':
    print(torch.__version__)
    Net_Train()
